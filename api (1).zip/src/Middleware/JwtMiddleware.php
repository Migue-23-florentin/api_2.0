<?php

namespace App\Middleware;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Server\RequestHandlerInterface as RequestHandler;
use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use Monolog\Logger;

class JwtMiddleware implements MiddlewareInterface
{
    private $config;
    private $logger;

    public function __construct(array $config, Logger $logger)
    {
        $this->config = $config;
        $this->logger = $logger;
    }

    public function process(Request $request, RequestHandler $handler): Response
    {
        $token = $request->getHeaderLine('Authorization');

        if (!$token) {
            $this->logger->warning('Intento de acceso sin token');
            return $this->responderError('Token no proporcionado', 401);
        }

        try {
            // Eliminar el prefijo "Bearer " si está presente
            $token = str_replace('Bearer ', '', $token);
            $decoded = JWT::decode($token, new Key($this->config['jwt_secret'], 'HS256'));
            return $handler->handle($request->withAttribute('usuario', $decoded));
        } catch (\Exception $e) {
            $this->logger->warning('Intento de acceso con token inválido', ['error' => $e->getMessage()]);
            return $this->responderError('Token inválido', 401);
        }
    }

    private function responderError(string $mensaje, int $codigo): Response
    {
        $response = new \Slim\Psr7\Response();
        $response->getBody()->write(json_encode(['error' => $mensaje]));
        return $response->withStatus($codigo)->withHeader('Content-Type', 'application/json');
    }
}
