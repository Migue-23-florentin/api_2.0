<?php

use Dotenv\Dotenv;

$dotenv = Dotenv::createImmutable(__DIR__ . '/../../');
$dotenv->load();

return [
    'jwt_secret' => $_ENV['JWT_SECRET'],
    'jwt_refresh_secret' => $_ENV['JWT_REFRESH_SECRET'],
    'pgsql' => [
        'server' => $_ENV['DB_SERVER'],
        'port' => $_ENV['DB_PORT'],
        'db' => $_ENV['DB_DATABASE'],
        'user' => $_ENV['DB_USER'],
        'password' => $_ENV['DB_PASSWORD'],
    ],
    'cache_ttl' => 3600, // 1 hora
];
