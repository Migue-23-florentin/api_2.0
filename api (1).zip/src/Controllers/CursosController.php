<?php

namespace App\Controllers;

use PDO;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use App\Helpers\ResponseHelper;

class CursosController
{
    private $db;

    public function __construct(PDO $db)
    {
        $this->db = $db;
    }

    private function obtenerCursos(string $vista, string $modalidad, Request $request, Response $response): Response
    {
        $responseHelper = new ResponseHelper($response);
        $queryParams = $request->getQueryParams();
        $pagina = isset($queryParams['pagina']) ? (int)$queryParams['pagina'] : 1;
        $porPagina = isset($queryParams['por_pagina']) ? (int)$queryParams['por_pagina'] : 10;

        $offset = ($pagina - 1) * $porPagina;

        $whereConditions = [];
        $parameters = [];

        // Filtros
        if (isset($queryParams['ciudad'])) {
            $whereConditions[] = "ciudad ILIKE :ciudad";
            $parameters[':ciudad'] = '%' . $queryParams['ciudad'] . '%';
        }

        if (isset($queryParams['areas'])) {
            $whereConditions[] = "areas ILIKE :areas";
            $parameters[':areas'] = '%' . $queryParams['areas'] . '%';
        }

        if (isset($modalidad)) {
            $whereConditions[] = "desc_modalidad ILIKE :modalidad";
            $parameters[':modalidad'] = '%' . $modalidad . '%';
            $whereConditions[] = "disponible_inscripcion = :disponibilidad";
            $parameters[':disponibilidad'] = 1;
        }

        $whereClause = !empty($whereConditions) ? 'WHERE ' . implode(' AND ', $whereConditions) : '';

        $campos = "id_planificacion, modalidad, unidad_operativa, especialidad, areas, 
                       familia, fecha_inicio, fecha_fin, hora_desde, hora_hasta, dias_semanas, 
                       arancel, geolocation, cantidad_alumnos, cantidad_maxima_alumnos, 
                       direccion, edad_requerida, sala, barrio, ciudad, distrito, latitud, longitud, 
                       carga_horaria";

        // Seleccionar campos según la vista
        if ($vista === 'cursos_disponibles') {
            $campos = "id_planificacion, desc_modalidad as modalidad, desc_unidad_operativa as unidad_operativa, especialidad, 
                       areas, familia, fecha_inicio, fecha_fin, hora_desde, hora_hasta, dias_semanas, 
                       arancel, geolocation, cantidad_alumnos, cantidad_maxima_alumnos, 
                       direccion, edad_requerida, sala, desc_barrio as barrio, ciudad, distrito, horas, latitud, longitud, duracion_hs as carga_horaria, disponible_inscripcion as disponibilidad, 
                       objetivo_general";
        } else if ($vista === 'cursos_disponibles_emprendedurismo') {
            $campos = "$campos, disponibilidad";
        }

        $sql = "SELECT $campos 
                FROM planificacion.$vista 
                $whereClause 
                ORDER BY fecha_inicio 
                LIMIT :limit OFFSET :offset";

        $stmt = $this->db->prepare($sql);
        $stmt->bindValue(':limit', $porPagina, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);

        foreach ($parameters as $key => $value) {
            $stmt->bindValue($key, $value, PDO::PARAM_STR);
        }

        $stmt->execute();

        $cursos = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Contar total de cursos con los filtros aplicados
        $sqlCount = "SELECT COUNT(*) FROM planificacion.$vista $whereClause";
        $stmtCount = $this->db->prepare($sqlCount);
        foreach ($parameters as $key => $value) {
            $stmtCount->bindValue($key, $value, PDO::PARAM_STR);
        }
        $stmtCount->execute();
        $totalCursos = $stmtCount->fetchColumn();

        $resultado = [
            'cursos' => $cursos,
            'total' => $totalCursos,
            'pagina_actual' => $pagina,
            'por_pagina' => $porPagina,
            'total_paginas' => ceil($totalCursos / $porPagina)
        ];

        return $responseHelper->respondWithJson($resultado, 200, '');

    }

    public function cursosDisponibles(Request $request, Response $response): Response
    {
        return $this->obtenerCursos('cursos_disponibles', 'PRESENCIAL', $request, $response);
    }

    public function cursosDisponiblesADistancia(Request $request, Response $response): Response
    {
        return $this->obtenerCursos('cursos_disponibles', 'A DISTANCIA',  $request, $response);
    }

    public function cursosEmprendedurismo(Request $request, Response $response): Response
    {
        return $this->obtenerCursos('cursos_disponibles_emprendedurismo', null, $request, $response);
    }

    public function cursosGeneracionDigital(Request $request, Response $response): Response
    {
        return $this->obtenerCursos('cursos_disponibles_generacion_digital', null, $request, $response);
    }

    public function cursosAreas(Request $request, Response $response): Response
    {
        $responseHelper = new ResponseHelper($response);
        
        $sql = "SELECT areas as area FROM planificacion.cursos_disponibles GROUP BY areas ORDER BY areas";

        $stmt = $this->db->prepare($sql);

        $stmt->execute();

        $areas = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $responseHelper->respondWithJson($areas, 200, '');
    }

    public function cursosPorArea(Request $request, Response $response): Response
    {
        $responseHelper = new ResponseHelper($response);
        $params = $request->getParsedBody();

        // Seleccionar campos 
        $campos = "id_planificacion, desc_modalidad as modalidad, desc_unidad_operativa as unidad_operativa, especialidad, 
                    areas, familia, fecha_inicio, fecha_fin, hora_desde, hora_hasta, dias_semanas, 
                    arancel, geolocation, cantidad_alumnos, cantidad_maxima_alumnos, 
                    direccion, edad_requerida, sala, desc_barrio as barrio, ciudad, distrito, horas, latitud, longitud, duracion_hs as carga_horaria, disponible_inscripcion as disponibilidad, 
                    objetivo_general";

        $sql = "SELECT $campos 
                FROM planificacion.cursos_disponibles
                WHERE areas ILIKE :areas
                ORDER BY fecha_inicio";

        $stmt = $this->db->prepare($sql);
        $stmt->bindValue(':areas', $params['area'], PDO::PARAM_STR);
        $stmt->execute();

        $cursos = $stmt->fetchAll(PDO::FETCH_ASSOC);

       
        $resultado = [
            'cursos' => $cursos
        ];

        return $responseHelper->respondWithJson($resultado, 200, '');

    }

    public function obtenerCursoPorId(Request $request, Response $response, array $args): Response
    {
        $responseHelper = new ResponseHelper($response);
        $id = $args['id'];

        $campos = "id_planificacion, modalidad, unidad_operativa, especialidad,
            areas, familia, fecha_inicio, fecha_fin, hora_desde, hora_hasta, dias_semanas,
            arancel, geolocation, cantidad_alumnos, cantidad_maxima_alumnos,
            direccion, edad_requerida, sala, barrio, ciudad, distrito, latitud, longitud, carga_horaria,
            objetivo_general, tipo_curso";

        $camposCursosDisponibles = "id_planificacion, desc_modalidad as modalidad, desc_unidad_operativa as unidad_operativa, especialidad,
            areas, familia, fecha_inicio, fecha_fin, hora_desde, hora_hasta, dias_semanas,
            arancel, geolocation, cantidad_alumnos, cantidad_maxima_alumnos,
            direccion, edad_requerida, sala, desc_barrio as barrio, ciudad, distrito, latitud, longitud, 
            duracion_hs as carga_horaria,
            objetivo_general";

        $camposEmprendedurismoGeneracionDigital = "id_planificacion, modalidad, unidad_operativa, especialidad, 
            areas, familia, fecha_inicio, fecha_fin, hora_desde, hora_hasta, dias_semanas,
            arancel, geolocation, cantidad_alumnos, cantidad_maxima_alumnos,
            direccion, edad_requerida, sala, barrio, ciudad, distrito, latitud, longitud,
            carga_horaria, 
            null as objetivo_general";

        $sql = "SELECT $campos FROM (
                    SELECT $camposCursosDisponibles, 'cursos_disponibles' as tipo_curso FROM planificacion.cursos_disponibles WHERE disponible_inscripcion = 1
                    UNION ALL
                    SELECT $camposEmprendedurismoGeneracionDigital, 'cursos_disponibles_emprendedurismo' as tipo_curso FROM planificacion.cursos_disponibles_emprendedurismo
                    UNION ALL
                    SELECT $camposEmprendedurismoGeneracionDigital, 'cursos_disponibles_generacion_digital' as tipo_curso FROM planificacion.cursos_disponibles_generacion_digital
                ) AS cursos_combinados
                WHERE id_planificacion = :id";

        try {
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':id', $id, PDO::PARAM_INT);
            $stmt->execute();

            $curso = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$curso) {
                return $responseHelper->respondWithError("Curso no encontrado", 404);
            }

            return $responseHelper->respondWithJson($curso, 200, "Curso encontrado exitosamente");
        } catch (\PDOException $e) {
            return $responseHelper->respondWithError("Error al obtener el curso: " . $e->getMessage(), 500);
        }
    }
}